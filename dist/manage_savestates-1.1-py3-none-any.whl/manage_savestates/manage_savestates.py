"""Running this file will manually run the program (as opposed to using the command line)."""
import main


main.main()
